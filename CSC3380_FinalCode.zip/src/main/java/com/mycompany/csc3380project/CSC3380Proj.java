/*
 * SmartCart Code
 * Group Members - Rian Mackie, Justin Gatlin, Adam Dupuy, Cameron Bartels
 */

package com.mycompany.csc3380project;

import java.util.*;

public class CSC3380Proj {
    public static void main(String[] args){
        
        System.out.println("Welcome to SmartCart!");
        
        Scanner Admin = new Scanner(System.in); //Get admin name
        System.out.print("Enter your name: ");
        System.out.println();
        String name = Admin.nextLine();
        Admin newAdmin = new Admin(name);
        
        System.out.println(); 
        System.out.println("Enter the name of the Family: "); // create family/ get name
        Scanner ip = new Scanner(System.in);
        String ArrayElements = ip.nextLine();
        System.out.println(MakeFamily(ArrayElements));
        
        System.out.println("Would you like to add a member to your family?"); //Get family members
        Scanner ans = new Scanner(System.in);
        String yn = ans.nextLine();
        
        if(yn.equals("Yes")){
            boolean add = true;
        
            while(add){
                System.out.println("Enter family member name: ");
                Scanner mn = new Scanner(System.in);
                String Mem = mn.nextLine();
                Member newMem = new Member(Mem);

                System.out.println("Would you like add another member?");
                Scanner am = new Scanner(System.in);
                String addMem = am.nextLine();

                if(addMem.equals("Yes")){
                    add = true;
                }

                if(addMem.equals("No")){
                    add = false;
                }
            }
        }
        
        System.out.println();
        System.out.println("Would you like to create a list? - Yes or No"); //Create a list
        Scanner answer = new Scanner(System.in);
        String YN = answer.nextLine();
        
        if(YN.equals("Yes")){
            Scanner ListName = new Scanner(System.in);
            System.out.println("Enter list name: ");
            String LN = ListName.nextLine();
            
            ArrayList<String> NewItemList = new ArrayList<>();
            System.out.println(String.format("%s List is created", LN));
            
            System.out.println();
            System.out.println(addItems(NewItemList));
            
            System.out.println();
            System.out.println("Would you like to review your items by approving/rejecting them?"); //Check for approve/rejection
            Scanner AR = new Scanner(System.in);
            String AppRej = AR.nextLine();
            if(AppRej.equals("Yes")){
            System.out.println(Admin(NewItemList));
            }
            
            System.out.println("Would you like to view your grocery list?"); //Open grocery list
            Scanner VL = new Scanner(System.in);
            String view = VL.nextLine();
            if(view.equals("Yes")){
                System.out.println("Grocery List: ");
                for(int j = 0; j < NewItemList.size(); j++){
                    System.out.println(NewItemList.get(j) + " ");
                }
            }
            
            System.out.println();
            System.out.println(deleteList(NewItemList)); //Delete List
            
            System.out.println();
            if(NewItemList.isEmpty()){
                System.out.println("Your list is empty. You can Start a new one now!");
            }
            else
                System.out.println("You are now ready to go shopping!");
        }
    } 
    
    public static ArrayList<String> deleteList(ArrayList<String> dList){ //delete list
        
        Scanner answer = new Scanner(System.in);
        System.out.println("Would you like to delete this list?");
        String YN = answer.nextLine();
        
        if(YN.equals("Yes")){
            dList.clear();
            System.out.println("The list is deleted.");
        }
        
        return dList;
    }
    
    public static ArrayList<String> addItems(ArrayList<String> list){ //Add items to list
        
        Scanner name = new Scanner(System.in);
        Scanner yes = new Scanner(System.in);
        boolean answer = true;
        String answer2;
       
        System.out.println("Please enter the name of the item(s) you would like to add: ");
       
        //do while loop so you can add multiple items at a time
        do
        {
            String ItemName = name.nextLine();
            list.add(ItemName);
            //tells you what you put into the list
            System.out.println("You just added " + ItemName + " to the list.");
            System.out.println();
            System.out.println("Would you like to add another item? Type yes if you do and no if you would like to stop");
            answer2 = yes.nextLine();
            if (answer2.length()<=2) {
                answer = false;
            }
        }
        
        while (answer == true);
        
        return list; 
    }
    
    public static List<String> MakeFamily(String array) //Create Family
    {
      List<String> familyList = new ArrayList<>();
      familyList.add(array);
      return familyList;
    }
     
    public static ArrayList<String> Admin(ArrayList<String> approveList) { //Approve/Reject Items
        
        Scanner sc = new Scanner(System.in);
        int numval = 0;
        boolean TFvalue = true;
        
        
        for(int i = 0; i < approveList.size(); i++){
            System.out.println("Approve(Y)/Reject(N): " + approveList.get(i));
            String input = sc.next();
            input.toUpperCase();

            if(input.equals("Y")){
                numval = 0;
            }
            else if (input.equals("N")){
                numval = 1;
            }

            if( numval == 1){
                String r = approveList.get(i);
                approveList.remove(r);
                TFvalue = false;
            }
            else if ( numval == 0){
                TFvalue = true;
            }
        
        }
        
        return approveList;
        
    }
    
    public static ArrayList<String> viewList(ArrayList<String> List){
        return List;
    }
}
